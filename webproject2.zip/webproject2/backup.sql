DROP SCHEMA IF EXISTS eventsplan;
CREATE DATABASE eventsplan;
USE eventsplan;

CREATE TABLE users (
    email VARCHAR(127),
    family_name VARCHAR(63),
    given_name VARCHAR(63),
    free_date DATETIME,
    password VARCHAR(255),
    PRIMARY KEY (email)
);

-- CREATE TABLE manage_user (
--     id INT NOT NULL AUTO_INCREMENT,
--     users VARCHAR(127),
--     PRIMARY KEY (id),
--     FOREIGN KEY (users) REFERENCES users(email) ON DELETE CASCADE
-- );

CREATE TABLE event_detail (
    id INT NOT NULL AUTO_INCREMENT,
    event_name VARCHAR(63),
    date DATETIME,
    event_detail VARCHAR(255),
    creator VARCHAR(127),
    PRIMARY KEY (id),
    FOREIGN KEY (creator) REFERENCES users(email) ON DELETE CASCADE
);

CREATE TABLE events_plan (
    id INT NOT NULL AUTO_INCREMENT,
    users VARCHAR(127),
    detail INT,
    PRIMARY KEY (id),
    FOREIGN KEY (users) REFERENCES users(email) ON DELETE CASCADE,
    FOREIGN KEY (detail) REFERENCES event_detail(id) ON DELETE CASCADE
);

CREATE TABLE admin (
     email VARCHAR(127),
     password VARCHAR(63),
     PRIMARY KEY (email)
 );