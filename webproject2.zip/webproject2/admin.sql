DROP SCHEMA IF EXISTS admin_plan;
CREATE DATABASE admin_plan;
USE admin_plan;

-- CREATE TABLE admins (
--     id  SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
--     admin_name VARCHAR(63),
--     psw VARCHAR(63),
--     PRIMARY KEY (id)
-- );

CREATE TABLE admins (
  actor_id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  admin_name VARCHAR(45) NOT NULL,
  psw VARCHAR(45) NOT NULL,
  PRIMARY KEY  (actor_id),
);