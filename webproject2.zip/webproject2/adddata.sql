-- INSERT INTO event_detail (id, event_name, date, event_detail, attendee) VALUES (1, 'name1', '2022-01-01 00:00:00', 'detail1', 22),
-- (2, 'name2', '2022-01-01 00:00:02', 'detail2', 24),
-- (3, 'name3', '2022-01-02 00:00:03', 'detail3', 32),
-- (4, 'name4', '2022-01-03 00:00:04', 'detail4', 4),
-- (5, 'name5', '2022-01-04 00:00:05', 'detail5', 67),
-- (6, 'name6', '2022-01-05 00:00:06', 'detail6', 3);

INSERT INTO users VALUES ('11111@qq.com', 'Anson', 'AA', '123456'),
('22222@qq.com', 'Bnson', 'BB', '234567'),
('33333@qq.com', 'Cnson', 'CC', '345678'),
('44444@qq.com', 'Dnson', 'DD', '456789'),
('55555@qq.com', 'Enson', 'EE', '5678910');

INSERT INTO events_plan VALUES (1, '11111@qq.com'),
(2, '22222@qq.com'),
(3, '33333@qq.com'),
(4, '44444@qq.com'),
(5, '55555@qq.com');

INSERT INTO events_plan VALUES (1, '11111@qq.com'),
(2, '22222@qq.com'),
(3, '33333@qq.com'),
(4, '44444@qq.com'),
(5, '55555@qq.com');


SELECT email FROM admins WHERE email = "1111@qq.com" AND passwords = "1234";


INSERT INTO admins (email, passwords) VALUES ('1111@qq.com', '1234');