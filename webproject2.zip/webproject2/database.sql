DROP SCHEMA IF EXISTS eventsplan;
CREATE DATABASE eventsplan;
USE eventsplan;

CREATE TABLE users (
    email VARCHAR(127),
    family_name VARCHAR(63),
    given_name VARCHAR(63),
    free_date DATETIME,
    password VARCHAR(255),
    PRIMARY KEY (email)
);

-- CREATE TABLE manage_user (
--     id INT NOT NULL AUTO_INCREMENT,
--     users VARCHAR(127),
--     PRIMARY KEY (id),
--     FOREIGN KEY (users) REFERENCES users(email) ON DELETE CASCADE
-- );

CREATE TABLE event_detail (
    id INT NOT NULL AUTO_INCREMENT,
    event_name VARCHAR(63),
    date DATETIME,
    event_detail VARCHAR(255),
    creator VARCHAR(127),
    PRIMARY KEY (id),
    FOREIGN KEY (creator) REFERENCES users(email) ON DELETE CASCADE
);

CREATE TABLE events_plan (
    id INT NOT NULL AUTO_INCREMENT,
    users VARCHAR(127),
    detail INT,
    PRIMARY KEY (id),
    FOREIGN KEY (users) REFERENCES users(email) ON DELETE CASCADE,
    FOREIGN KEY (detail) REFERENCES event_detail(id) ON DELETE CASCADE
);

-- CREATE TABLE admins (
--     id INT NOT NULL AUTO_INCREMENT,
--     email VARCHAR(127),
--     admin_name VARCHAR(63),
--     passwords VARCHAR(63),
--     event_plan INT,
--     manage_user INT,
--     PRIMARY KEY (id),
--     FOREIGN KEY (event_plan) REFERENCES events_plan(id) ON DELETE CASCADE,
--     FOREIGN KEY (manage_user) REFERENCES manage_user(id) ON DELETE CASCADE
-- );
CREATE TABLE admin (
     email VARCHAR(127),
     password VARCHAR(63),
     PRIMARY KEY (email)
 );


INSERT INTO users VALUES ('11111@qq.com', 'Anson', 'AA', '2022-01-01 00:03:02', '123456'),
('22222@qq.com', 'Bnson', 'BB', '2022-01-01 00:04:02', '234567'),
('33333@qq.com', 'Cnson', 'CC', '2022-01-01 00:05:02', '345678'),
('44444@qq.com', 'Dnson', 'DD', '2022-01-01 00:02:02', '456789'),
('55555@qq.com', 'Enson', 'EE', '2022-01-01 00:04:02', '5678910');

INSERT INTO event_detail VALUES (1, 'name1', '2022-01-01 00:00:00', 'detail1','11111@qq.com'),
(2, 'name2', '2022-01-01 00:00:02', 'detail2', '33333@qq.com'),
(3, 'name3', '2022-01-02 00:00:03', 'detail3', '33333@qq.com'),
(4, 'name4', '2022-01-03 00:00:04', 'detail4', '22222@qq.com'),
(5, 'name5', '2022-01-04 00:00:05', 'detail5', '55555@qq.com'),
(6, 'name6', '2022-01-05 00:00:06', 'detail6', '44444@qq.com');

INSERT INTO events_plan VALUES (1, '11111@qq.com', 1),
(2, '22222@qq.com', 4),
(3, '33333@qq.com', 2),
(4, '33333@qq.com', 3),
(5, '44444@qq.com', 6),
(6, '55555@qq.com', 5);