function sign_in() {
  var email = document.getElementById("email").value;
  var password = document.getElementById("password").value;
  var admin = {adminemail: email, adminpassword: password};

  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
      if (this.readyState == 4 && this.status == 200) {
        alert("login successful");
        console.log("login successful");
        window.location.replace("admin.html");
      } else if (this.readyState == 4 && this.status >= 400) {
        alert("login failed");
        console.log("login failed");
      }
};

xhttp.open("POST", "/sign_in", true);
xhttp.setRequestHeader("Content-type", "application/json");
xhttp.send(JSON.stringify(admin));
}

function sign_up() {
let email = document.getElementById("email").value;
let psw = document.getElementById("password").value;
let query = {email: email, password: psw};
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        alert("registered successfully");
    } else if (this.readyState == 4 && this.status >= 400) {
        alert("the mailbox already exists");
    }
};
xhttp.open("POST", "/sign_up", true);
xhttp.setRequestHeader("Content-type", "application/json");
xhttp.send(JSON.stringify(query));
}