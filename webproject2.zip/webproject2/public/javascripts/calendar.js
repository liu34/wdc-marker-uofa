
function getevents() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var events = JSON.parse(this.responseText);

            for (let i = 0; i < events.length; i++) {
                var row = document.createElement("tr");
                var event_name = document.createElement("td");
                var date = document.createElement("td");
                var event_detail = document.createElement("td");
                var creator = document.createElement("td");
                table_body.appendChild(row);
                row.appendChild(event_name);
                row.appendChild(date);
                row.appendChild(event_detail);
                row.appendChild(creator);
                var buttoninside = document.createElement("button");
                event_name.innerHTML = events[i].event_name;
                date.innerHTML = events[i].date;
                event_detail.innerHTML = events[i].event_detail;
                creator.innerHTML = events[i].creator;
            }
        }
    };
    xhttp.open("GET", "/events", true);
    xhttp.send();
  }

function getyourevents() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
          var events = JSON.parse(this.responseText);

          for (let i = 0; i < events.length; i++) {
              var row = document.createElement("tr");
              var event_name = document.createElement("td");
              var date = document.createElement("td");
              var event_detail = document.createElement("td");
              table_body2.appendChild(row);
              row.appendChild(event_name);
              row.appendChild(date);
               row.appendChild(event_detail);
               event_name.innerHTML = events[i].event_name;
               date.innerHTML = events[i].date;
               event_detail.innerHTML = events[i].event_detail;
           }
       }
   };
  xhttp.open("GET", "/yourevents", true);
  xhttp.send();
}




function start() {
  getevents();
  getyourevents();
}

function get_event_id(join_event) {
    var creator = document.getElementById("creator").value;
    var date = document.getElementById("date").value;
    var event = {creator: creator, date: date};

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
          // var event_detail = JSON.parse(this.responseText);
          console.log("get sucessful");
        } else if (this.readyState == 4 && this.status >= 400) {
          alert("wrong date or creator");
        }
  };

  xhttp.open("POST", "/get_event_id", false);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(event));

}

function join_event() {
  var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
          alert("add successful");
        } else if (this.readyState == 4 && this.status >= 400) {
          alert("add failed please try again");
        }
    };
    xhttp.open("GET", "/join_event", false);
    xhttp.send();
}



function go_event() {
  get_event_id();
  join_event();
}