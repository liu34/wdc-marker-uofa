function find_user() {
    let user=document.getElementById("user").value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4 && this.status == 200) {
          var user_infor = JSON.parse(this.responseText);
          for(let i=0;i<user_infor.length;i++){
              var body = document.getElementById("t_body");
              var row = document.createElement("tr");
              var first_name = document.createElement("td");
              var last_name = document.createElement("td");
              var psw = document.createElement("td");
              var email = document.createElement("td");
              body.appendChild(row);
              row.appendChild(first_name);
              row.appendChild(last_name);
              row.appendChild(psw);
              row.appendChild(email);
              first_name.innerHTML = user_infor[i].family_name;
              last_name.innerHTML = user_infor[i].given_name;
              psw.innerHTML = user_infor[i].password;
              email.innerHTML=user_infor[i].email;
          }
      }
  };
  xhttp.open("GET", "/users/find_infor?email="+(user), true);
  xhttp.send();
}

function find_event() {
    let event = document.getElementById("event").value;
    let query = {event: event};
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4 && this.status == 200) {
          var user_infor = JSON.parse(this.responseText);
          for(let i=0;i<user_infor.length;i++){
              var body = document.getElementById("t_body1");
              var row = document.createElement("tr");
              var user= document.createElement("td");
              var event = document.createElement("td");
              var time = document.createElement("td");
              body.appendChild(row);
              row.appendChild(user);
              row.appendChild(event);
              row.appendChild(time);
              user.innerHTML = user_infor[i].creator;
              event.innerHTML = user_infor[i].event_name;
              time.innerHTML = user_infor[i].date;
          }
      }
  };
    xhttp.open("POST", "/users/find_event", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(query));
}

function delete_user() {
    let user_email = document.getElementById("user_delete").value;
    let query = {user_email: user_email};
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            alert("delete successful");
            window.location.reload();
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("incorrect email")
        }
    };
    xhttp.open("POST", "/users/delete_user", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(query));
}

function delete_event() {
    let event_name = document.getElementById("event").value;
    let query = {event_name: event_name};
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            alert("delete successful");
            window.location.reload();
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("incorrect event name")
        }
    };
    xhttp.open("POST", "/users/delete_event", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(query));
}
