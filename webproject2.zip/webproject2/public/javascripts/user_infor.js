function get_user_infor() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var user_mail = document.getElementById("user_mail");
            user_mail.innerHTML = this.responseText;
        }
    };
  xhttp.open("GET", "/get_user_infor", true);
  xhttp.send();
}

function change_fname() {
    let fname = document.getElementById("familyname").value;
    let query = {familyname: fname};

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            alert("add successful");
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("add failed");
        }
  };

  xhttp.open("POST", "/change_fname", true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(query));
}

function change_lname() {
    let lname = document.getElementById("givenname").value;
    let query = {givenname: lname};

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            alert("add successful");
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("add failed");
        }
  };

  xhttp.open("POST", "/change_lname", true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(query));
}

function change_psw() {
    let password = document.getElementById("password").value;
    let query = {password: password};

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            alert("add successful");
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("add failed");
        }
  };

  xhttp.open("POST", "/change_psw", true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(query));
}

function start() {
    change_fname();
    change_lname();
    change_psw();
}