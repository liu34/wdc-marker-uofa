function find_user() {
    let user=document.getElementById("user").value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4 && this.status == 200) {
          var user_infor = JSON.parse(this.responseText);
          for(let i=0;i<user_infor.length;i++){
              var body = document.getElementById("t_body");
              var row = document.createElement("tr");
              var first_name = document.createElement("td");
              var last_name = document.createElement("td");
              var psw = document.createElement("td");
              var email = document.createElement("td");
              body.appendChild(row);
              row.appendChild(first_name);
              row.appendChild(last_name);
              row.appendChild(psw);
              row.appendChild(email);
              first_name.innerHTML = user_infor[i].first_name;
              last_name.innerHTML = user_infor[i].last_name;
              psw.innerHTML = user_infor[i].psw;
              email.innerHTML=user_infor[i].email;
          }
      }
  };
  xhttp.open("GET", "/users/find_infor?email="+(user), true);
  xhttp.send();
}

function find_event() {
    let event=document.getElementById("event").value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4 && this.status == 200) {
          var user_infor = JSON.parse(this.responseText);
          for(let i=0;i<user_infor.length;i++){
              var body = document.getElementById("t_body");
              var row = document.createElement("tr");
              var user= document.createElement("td");
              var event = document.createElement("td");
              var time = document.createElement("td");
              body.appendChild(row);
              row.appendChild(user);
              row.appendChild(event);
              row.appendChild(time);
              user.innerHTML = user_infor[i]. user;
              event.innerHTML = user_infor[i].event;
              time.innerHTML = user_infor[i].time;
          }
      }
  };
  xhttp.open("GET", "/users/find_event?="+encodeURIComponent(event), true);
  xhttp.send();
}

