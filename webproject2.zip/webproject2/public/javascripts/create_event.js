function addevent() {
    let event_name = document.getElementById("event_name").value;
    let date = document.getElementById("date").value;
    let detail = document.getElementById("detail").value;
    let query = {event_name: event_name, date: date, detail: detail};
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            alert("add successful");
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("incorrect email")
        }
    };
    xhttp.open("POST", "/add_event", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(query));
}