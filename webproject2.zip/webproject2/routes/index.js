var express = require('express');
var router = express.Router();
var path = require('path');


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


router.post("/sign_in", function(req, res, next) {
  req.pool.getConnection(function(err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    var email = req.body.adminemail;
    var password = req.body.adminpassword;
    var query = "SELECT * FROM admin WHERE email = ?;";
    connection.query(query, [email], function(err, rows, fields) {
      connection.release();
      if(err) {
        res.sendStatus(500);
        return;
      }
      // console.log(rows.length);
      if (rows.length == 0) {
        console.log("incorrect email");
        res.sendStatus(401);
      } else if (rows[0].password == password) {
        console.log('correct');
        req.session.user = rows[0];
        res.sendStatus(200);
      } else {
        console.log("incorrect password");
        res.sendStatus(401);
      }
    });
  });
});

router.post("/sign_up", function(req, res, next) {
  req.pool.getConnection(function(err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    var email = req.body.email;
    var psw = req.body.password;
    var query = "INSERT INTO admin (email, password) VALUES (?, ?);";
    // var query = "INSERT INTO admins (admin_name, psw) VALUES (?, ?);";
    connection.query(query, [email, psw], function(err, rows, fields) {
      connection.release();
      if(err) {
        res.sendStatus(500);
        return;
      }
      res.end();
    });
  });
});

router.post("/user_sign_in", function(req, res, next) {
  req.pool.getConnection(function(err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    var email = req.body.useremail;
    var password = req.body.userpassword;
    var query = "SELECT * FROM users WHERE email = ?;";
    connection.query(query, [email], function(err, rows, fields) {
      connection.release();
      if(err) {
        res.sendStatus(500);
        return;
      }
      // console.log(rows.length);
      if (rows.length == 0) {
        console.log("incorrect email");
        res.sendStatus(401);
      } else if (rows[0].password == password) {
        console.log('correct');
        req.session.user = rows[0];
        res.sendStatus(200);
      } else {
        console.log("incorrect password");
        res.sendStatus(401);
      }
    });
  });
});

router.post("/user_sign_up", function(req, res, next) {
  req.pool.getConnection(function(err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    var email = req.body.email;
    var psw = req.body.password;
    var query = "INSERT INTO users (email, password) VALUES (?, ?);";
    // var query = "INSERT INTO admins (admin_name, psw) VALUES (?, ?);";
    connection.query(query, [email, psw], function(err, rows, fields) {
      connection.release();
      if(err) {
        res.sendStatus(500);
        return;
      }
      res.end();
    });
  });
});


router.get('/events', function(req, res, next) {
  req.pool.getConnection(function(err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    var query = "SELECT event_name, date, event_detail, creator FROM event_detail;";
    connection.query(query, function(err, rows, fields) {
      connection.release();
      if(err) {
        res.sendStatus(500);
        return;
      }
      res.json(rows);
    });
  });
});


router.get('/yourevents', function(req, res, next) {
  req.pool.getConnection(function(err, connection) {
    if (err) {
      // console.log(err)
      res.sendStatus(500);
      return;
    }
    var query = "SELECT event_detail.event_name, event_detail.date, event_detail.event_detail FROM event_detail, events_plan WHERE events_plan.users = ? AND events_plan.detail = event_detail.id;";
    connection.query(query, [req.session.user.email], function(err, rows, fields) {
      connection.release();
      if(err) {
        console.log(err)
        res.sendStatus(500);
        return;
      }
      res.json(rows);
    });
  });
});


router.post('/add_event', function(req, res, next) {
  req.pool.getConnection(function(err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    var event_name = req.body.event_name;
    var date = req.body.date;
    var detail = req.body.detail;
    // var email = req.body.email;


    var query = "INSERT INTO event_detail(event_name, date, event_detail, user) VALUES (?, ?, ?, ?);";
    connection.query(query, [event_name, date, detail, req.session.user.email], function(err, rows, fields) {
      connection.release();
      if(err) {
        res.sendStatus(500);
        return;
      }
      res.json(rows);
    });
  });

});

router.get('/get_user_infor', function(req, res, next) {
  var email = req.session.user.email;
  res.send(email);
});

router.post("/change_fname", function(req, res, next) {
  req.pool.getConnection(function(err, connection) {
    if (err) {
      console.log(err);
      res.sendStatus(500);
      return;
    }
    var fname = req.body.familyname;

    var query = "UPDATE users SET family_name = ? WHERE email = ?;";
    connection.query(query, [fname, req.session.user.email], function(err, rows, fields) {
      connection.release();
      if(err) {
        console.log(err)
        res.sendStatus(500);
        return;
      }
      res.end();
    });
  });
});

router.post("/change_lname", function(req, res, next) {
  req.pool.getConnection(function(err, connection) {
    if (err) {
      console.log(err);
      res.sendStatus(500);
      return;
    }
    var lname = req.body.givenname;;

    var query = "UPDATE users SET given_name = ? WHERE email = ?;";
    connection.query(query, [lname, req.session.user.email], function(err, rows, fields) {
      connection.release();
      if(err) {
        console.log(err)
        res.sendStatus(500);
        return;
      }
      res.end();
    });
  });
});

router.post("/change_psw", function(req, res, next) {
  req.pool.getConnection(function(err, connection) {
    if (err) {
      console.log(err);
      res.sendStatus(500);
      return;
    }
    var password = req.body.password;

    var query = "UPDATE users SET password = ? WHERE email = ?;";
    connection.query(query, [password, req.session.user.email], function(err, rows, fields) {
      connection.release();
      if(err) {
        console.log(err)
        res.sendStatus(500);
        return;
      }
      res.end();
    });
  });
});

router.post("/get_event_id", function(req, res, next) {
  req.pool.getConnection(function(err, connection) {
    if (err) {
      console.log(err);
      res.sendStatus(500);
      return;
    }
    var creator = req.body.creator;
    var date = req.body.date;

    var query = "SELECT * FROM event_detail WHERE date = ? AND creator = ?";
    connection.query(query, [date, creator], function(err, rows, fields) {
      connection.release();
      if(err) {
        // console.log(err)
        res.sendStatus(500);
        return;
      }
      if (rows.length == 0) {
        res.sendStatus(401);
      } else {
        // console.log(rows[0])
        req.session.event = rows[0];
        console.log(req.session.event.id);
        res.sendStatus(200);
      }
    });
  });
});

router.get('/join_event', function(req, res, next) {
  req.pool.getConnection(function(err, connection) {
    if (err) {
      // console.log(err)
      res.sendStatus(500);
      return;
    }
    // var id = req.session.event.id;
    var query = "INSERT INTO events_plan(users, detail) VALUES (?, ?);";
    connection.query(query, [req.session.user.email, req.session.event.id], function(err, rows, fields) {
      connection.release();
      if(err) {
        console.log(err)
        res.sendStatus(500);
        return;
      }
      res.json(rows);
    });
  });
});


//[fname, req.session.user.email, lname, req.session.user.email], UPDATE users SET given_name = 'Yuu' WHERE email = '11111@qq.com';


module.exports = router;
