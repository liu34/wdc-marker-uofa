var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});


router.get('/find_infor', function(req, res, next) {
    req.pool.getConnection(function(err, connection) {
       if (err) {
           console.log(err)
         res.sendStatus(500);
         return;
       }
         console.log(req.query.email)
         var query = "SELECT * FROM users where email= ? ;";
         connection.query(query,[req.query.email],function(err, rows, fields) {
         connection.release();
          if(err) {
              console.log(err)
             res.sendStatus(500);
             return;
          }
             res.json(rows);
          });
      });
});

router.post("/find_event", function(req, res, next) {
    req.pool.getConnection(function(err, connection) {
      if (err) {
        console.log(err);
        res.sendStatus(500);
        return;
      }

      var query = "SELECT * FROM event_detail WHERE event_name = ?;";
      connection.query(query, [req.body.event], function(err, rows, fields) {
        connection.release();
        if(err) {
          res.sendStatus(500);
          return;
        }
        res.json(rows);
      });
    });
  });

router.post("/delete_user", function(req, res, next) {
    req.pool.getConnection(function(err, connection) {
      if (err) {
        console.log(err);
        res.sendStatus(500);
        return;
      }

      var query = "DELETE FROM users WHERE email = ?;";
      connection.query(query, [req.body.user_email], function(err, rows, fields) {
        connection.release();
        if(err) {
          console.log(err)
          res.sendStatus(500);
          return;
        }
        res.end();
      });
    });
  });

  router.post("/delete_event", function(req, res, next) {
    req.pool.getConnection(function(err, connection) {
      if (err) {
        console.log(err);
        res.sendStatus(500);
        return;
      }

      var query = "DELETE FROM event_detail WHERE event_name = ?;";
      connection.query(query, [req.body.event_name], function(err, rows, fields) {
        connection.release();
        if(err) {
          console.log(err)
          res.sendStatus(500);
          return;
        }
        res.end();
      });
    });
  });

module.exports = router;
